package com.example.davinder_pc.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import com.example.davinder_pc.inventory.InventoryContract.InvEntry;
/**
 * Created by Davinder-PC on 5/31/2017.
 */

public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "inventory.db";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_INVENTORY_TABLE = "CREATE TABLE " + InvEntry.TABLE_NAME + " (" +
                InvEntry.COLUMN_PRODUCT_ID + " INTEGER PRIMARY KEY," +
                InvEntry.COLUMN_PRODUCT_NAME + " TEXT NOT NULL, " +
                InvEntry.COLUMN_PRODUCT_QUANTITY + " INTEGER NOT NULL, " +
                InvEntry.COLUMN_PRODUCT_PRICE + " INTEGER NOT NULL," +
                InvEntry.COLUMN_PRODUCT_IMAGE + " BLOB NOT NULL)";
        sqLiteDatabase.execSQL(SQL_CREATE_INVENTORY_TABLE);
    }



    public boolean addData(String Name, int quantity, int price,byte[] image) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(InvEntry.COLUMN_PRODUCT_NAME, Name);
        contentValues.put(InvEntry.COLUMN_PRODUCT_QUANTITY, quantity);
        contentValues.put(InvEntry.COLUMN_PRODUCT_PRICE, price);
        contentValues.put(InvEntry.COLUMN_PRODUCT_IMAGE, image);
        database.insert(InvEntry.TABLE_NAME, null, contentValues);
        return true;
    }

    public ArrayList<String> getData() {
        ArrayList<String> products = new ArrayList<String>();

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur = database.rawQuery("SELECT * FROM " + InvEntry.TABLE_NAME, null);
        cur.moveToFirst();
        while (cur.isAfterLast() == false) {
            String name = cur.getString(cur.getColumnIndex(InvEntry.COLUMN_PRODUCT_NAME));
            int quantity = cur.getInt(cur.getColumnIndex(InvEntry.COLUMN_PRODUCT_QUANTITY));
            int price = cur.getInt(cur.getColumnIndex(InvEntry.COLUMN_PRODUCT_PRICE));
            products.add(name + "\n" + "Quantity: " + quantity + "\n" + "Price: $" + price);
            cur.moveToNext();
        }
        return products;
    }

    public Cursor getData(String name) {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * from " + InvEntry.TABLE_NAME +
                " WHERE name=\"" + name + "\"", null);
        return cursor;
    }


    public void updateData(String name, int quantity, int newQuantity) {
        SQLiteDatabase database = this.getWritableDatabase();
        String str = "UPDATE " + InvEntry.TABLE_NAME + " SET quantity = "
                + (quantity + newQuantity) + " WHERE name = \"" + name + "\"";
        database.execSQL(str);
    }


    public boolean deleteData(String name) {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete(InvEntry.TABLE_NAME, "name=?", new String[]{name}) > 0;
    }


    public int deleteAll() {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete(InvEntry.TABLE_NAME, null, null);
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int j) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + InvEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}

