package com.example.davinder_pc.inventory;

import android.provider.BaseColumns;

/**
 * Created by Davinder-PC on 5/31/2017.
 */

public class InventoryContract {
    public static final class InvEntry implements BaseColumns {

        public static final String TABLE_NAME = "inventory";
        public static final String COLUMN_PRODUCT_ID = "id";
        public static final String COLUMN_PRODUCT_NAME = "name";
        public static final String COLUMN_PRODUCT_QUANTITY = "quantity";
        public static final String COLUMN_PRODUCT_IMAGE="image";
        public static final String COLUMN_PRODUCT_PRICE = "price";
    }
}
