package com.example.davinder_pc.inventory;

import android.content.Context;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.example.davinder_pc.inventory.InventoryContract.InvEntry;

/**
 * Created by Davinder-PC on 5/31/2017.
 */

public class InventoryAdapter extends ArrayAdapter<String> {

    private final Context mContext;

    public InventoryAdapter(Context inv, ArrayList<String> list) {

        super(inv, 0, list);
        this.mContext = inv;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
       View listView = convertView;
        if(listView == null){
            listView = LayoutInflater.from(getContext()).inflate(R.layout.inventory_list_item, parent, false);
        }
        final String thisItem = getItem(position);
        TextView itemInfo = (TextView)listView.findViewById(R.id.item_info);
        itemInfo.setText(thisItem);

        Button sell = (Button)listView.findViewById(R.id.sellItem);

        sell.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                final DbHelper database = new DbHelper(getContext());
                int pos = thisItem.indexOf("\nQuantity");
                final String Name = thisItem.substring(0,pos);
                final Cursor cursor = database.getData(Name);
                if(cursor.moveToFirst()){
                    int itemQuantity = cursor.getInt(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_QUANTITY));
                    if(itemQuantity > 0)
                    {
                        database.updateData(Name,itemQuantity,-1);
                        Toast.makeText(getContext(), "One Item Sold",Toast.LENGTH_SHORT).show();
                        if(mContext instanceof MainActivity){
                            ((MainActivity)mContext).refresh();
                        }
                    }
                    else
                    {
                        if(itemQuantity <= 0)
                        {
                            Toast.makeText(getContext(), "No items left",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        TextView set = (TextView) listView.findViewById(R.id.item_info);
        set.setText(thisItem);
        return listView;
    }
}
