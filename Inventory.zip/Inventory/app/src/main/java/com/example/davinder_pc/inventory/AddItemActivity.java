package com.example.davinder_pc.inventory;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class AddItemActivity extends AppCompatActivity {

    private int Product_image = 1;
    byte[] image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        final DbHelper database = new DbHelper(this);
        Button save = (Button) findViewById(R.id.save_data);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText Item_Name = (EditText) findViewById(R.id.item_name);
                EditText Item_Quantity = (EditText) findViewById(R.id.item_quantity);
                EditText Item_Price = (EditText) findViewById(R.id.item_price);

                String product_name = Item_Name.getText().toString();
                if (product_name.equals("")) {
                    Toast.makeText(AddItemActivity.this, "Product Name Cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                String exist_quantity = Item_Quantity.getText().toString();
                if (exist_quantity.equals("")) {
                    Toast.makeText(AddItemActivity.this, "Quantity Cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                int product_quantity = Integer.parseInt(exist_quantity);

                String exist_price = Item_Price.getText().toString();
                if (exist_price.matches("")) {
                    Toast.makeText(AddItemActivity.this, "Price Cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                int product_price = Integer.parseInt(exist_price);

                if(image == null) {
                    Toast.makeText(AddItemActivity.this, "Please Inset An Image", Toast.LENGTH_SHORT).show();
                    return;
                }

                database.addData(product_name, product_quantity, product_price, image);
                Intent mainIntent = new Intent(AddItemActivity.this, MainActivity.class);
                startActivity(mainIntent);
                String message = "Product Added!";
                Toast.makeText(AddItemActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
        Button addImage = (Button) findViewById(R.id.item_image);
        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, Product_image);
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent) {

        if (request == Product_image && result == RESULT_OK && intent!=null) {
            Bundle bundles = intent.getExtras();
            Bitmap imageBitmap = (Bitmap) bundles.get("data");

            // Convert Bitmap to byte array
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
            image = stream.toByteArray();
        }
    }
}
