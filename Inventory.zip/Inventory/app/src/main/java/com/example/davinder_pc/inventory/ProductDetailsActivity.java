package com.example.davinder_pc.inventory;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.davinder_pc.inventory.InventoryContract.InvEntry;
import java.io.ByteArrayInputStream;

public class ProductDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        final DbHelper database = new DbHelper(this);
        Intent List = getIntent();
        String product = List.getExtras().getString("listItem");
        int pos = product.indexOf("\nQuantity");
        final String sub_product = product.substring(0, pos);

        final Cursor cursor = database.getData(sub_product);

        if (cursor.moveToFirst()) {

            TextView productName = (TextView)findViewById(R.id.nameDetail);
            productName.setText(sub_product);

            int Productquantity = cursor.getInt(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_QUANTITY));
            TextView tQuantity = (TextView) findViewById(R.id.quantityDetail);
            tQuantity.setText("" + Productquantity);

            int ProductPrice = cursor.getInt(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_PRICE));
            TextView tPrice = (TextView) findViewById(R.id.priceDetail);
            tPrice.setText("$" + ProductPrice);



            ImageView ProductImage = (ImageView) findViewById(R.id.product_photo);
            byte[] blob = cursor.getBlob(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_IMAGE));
            ByteArrayInputStream inputStream = new ByteArrayInputStream(blob);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            ProductImage.setImageBitmap(bitmap);
        }

        Button orderButton = (Button) findViewById(R.id.order);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Product = "";
                if (cursor.moveToFirst()) {
                    Product = cursor.getString(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_NAME));
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("message/rfc822");
                send.putExtra(Intent.EXTRA_TEXT, "Require More of " + Product);
                startActivity(Intent.createChooser(send, "Send Email"));
            }
        });

        Button itemDelete = (Button) findViewById(R.id.delete_item);
        itemDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        switch (i) {
                            case DialogInterface.BUTTON_POSITIVE:
                                if (database.deleteData(sub_product)) {
                                    Intent main_activity = new Intent(ProductDetailsActivity.this, MainActivity.class);
                                    startActivity(main_activity);
                                    Toast.makeText(ProductDetailsActivity.this, "Item Removed", Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                break;
                        }
                    }
                };
                AlertDialog.Builder alert = new AlertDialog.Builder(ProductDetailsActivity.this);
                alert.setMessage("Are you sure you want to Remove?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });

        Button sellMultiple = (Button) findViewById(R.id.sell_multiple);
        sellMultiple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText change = (EditText) findViewById(R.id.purchase_quantity);
                String removeQuantity = change.getText().toString();
                if(removeQuantity != "")
                {
                    removeQuantity = "-" + removeQuantity;
                    int changeQuantity = Integer.parseInt(removeQuantity);
                    int changeQuantityPositive = changeQuantity*-1;
                    int quantity = cursor.getInt(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_QUANTITY));
                    if(quantity < changeQuantityPositive)
                        changeQuantity = quantity*-1;
                    database.updateData(sub_product, quantity, changeQuantity);
                    Intent mainIntent = new Intent(ProductDetailsActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                }
                else
                {
                    Toast.makeText(ProductDetailsActivity.this, "Cannot Be Empty", Toast.LENGTH_SHORT).show();
                }

            }
        });


        Button refreshData = (Button) findViewById(R.id.refresh_data);
        refreshData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText changeQuantity = (EditText) findViewById(R.id.change_data);
                String quantityString = changeQuantity.getText().toString();
                if(quantityString != null)
                {
                    int quantityChanges = Integer.parseInt(quantityString);
                    int quantity = cursor.getInt(cursor.getColumnIndex(InvEntry.COLUMN_PRODUCT_QUANTITY));
                    database.updateData(sub_product, quantity, quantityChanges);
                    Intent mainIntent = new Intent(ProductDetailsActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                }
                else
                {
                    Toast.makeText(ProductDetailsActivity.this, "Cannot Be Empty", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
