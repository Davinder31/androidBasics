package com.example.davinder_pc.booklist;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

/**
 * Created by Davinder-PC on 5/26/2017.
 */

public class BookListLoader extends AsyncTaskLoader<List<BookInfo>> {

    private String mUrl;

    public BookListLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<BookInfo> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        return QueryUtils.fetchData(mUrl);
    }
}
