package com.example.davinder_pc.booklist;

import android.app.LoaderManager.LoaderCallbacks;
import android.content.Context;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderCallbacks<List<BookInfo>> {
    private static String BOOK_API_URL;
    private static int LOADER_ID = 1;
    View loadingIndicator;
    private BookListAdapter mAdapter;
    private TextView EmptyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView bookListView = (ListView) findViewById(R.id.list);

        mAdapter = new BookListAdapter(MainActivity.this, new ArrayList<BookInfo>());
        bookListView.setAdapter(mAdapter);

        loadingIndicator = findViewById(R.id.loading_indicator);

        EmptyText = (TextView) findViewById(R.id.empty_view);
        bookListView.setEmptyView(EmptyText);
        EmptyText.setText(R.string.find_books);

        Button pushIt = (Button) findViewById(R.id.search_button);

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
       final NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        loadingIndicator.setVisibility(View.GONE);

        pushIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mAdapter.clear();

                if (networkInfo != null && networkInfo.isConnected()) {
                    android.app.LoaderManager loaderManager = getLoaderManager();
                    loadingIndicator.setVisibility(View.VISIBLE);
                    loaderManager.initLoader(LOADER_ID, null, MainActivity.this);

                EmptyText.setVisibility(View.GONE);
                EditText search_textBox = (EditText) findViewById(R.id.search_text);
                String item_searched = search_textBox.getText().toString().toLowerCase();

                BOOK_API_URL = "https://www.googleapis.com/books/v1/volumes?q=";


                for (int i = 0; i < item_searched.length(); i++) {
                    if (item_searched.charAt(i) == ' ') {
                        BOOK_API_URL = BOOK_API_URL + "%20";
                    } else
                        BOOK_API_URL = BOOK_API_URL + item_searched.charAt(i);
                }
                getLoaderManager().restartLoader(LOADER_ID, null, MainActivity.this);
                } else {
                    loadingIndicator.setVisibility(View.GONE);
                    EmptyText.setText(R.string.no_internet_connection);
                }

            }
        });
    }

    @Override
    public Loader<List<BookInfo>> onCreateLoader(int i, Bundle bundle) {
        return new BookListLoader(this, BOOK_API_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<BookInfo>> loader, List<BookInfo> data) {
        loadingIndicator.setVisibility(View.GONE);
        EmptyText.setText(R.string.not_found);
        mAdapter.clear();
        if (data != null && !data.isEmpty()) {
            mAdapter.addAll(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<BookInfo>> loader) {
        mAdapter.clear();
    }
}

