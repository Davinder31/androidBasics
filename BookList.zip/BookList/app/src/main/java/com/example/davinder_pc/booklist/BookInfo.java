package com.example.davinder_pc.booklist;

/**
 * Created by Davinder-PC on 5/26/2017.
 */

public class BookInfo {
    private final String mBookName;
    private final String mAuthor;

    public BookInfo(String bookName, String author) {
        mBookName = bookName;
        mAuthor = author;
    }

    public String getBookName() {
        return mBookName;
    }

    public String getAuthor() {
        return mAuthor;
    }

}
