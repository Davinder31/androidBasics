package com.example.davinder_pc.booklist;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Davinder-PC on 5/26/2017.
 */

public class BookListAdapter extends ArrayAdapter<BookInfo> {

    public BookListAdapter(Context context, ArrayList<BookInfo> bookInfo) {
        super(context, 0, bookInfo);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        BookInfo thisBook = getItem(position);
        TextView book_Name = (TextView) listView.findViewById(R.id.book_name);
        book_Name.setText(thisBook.getBookName());
        TextView author = (TextView) listView.findViewById(R.id.author);
        author.setText(thisBook.getAuthor());
        return listView;
    }
}
