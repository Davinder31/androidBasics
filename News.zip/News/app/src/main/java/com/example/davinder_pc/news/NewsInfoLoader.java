package com.example.davinder_pc.news;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

/**
 * Created by Davinder-PC on 5/28/2017.
 */

public class NewsInfoLoader extends AsyncTaskLoader<List<NewsInfo>> {

    private String mUrl;

    public NewsInfoLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<NewsInfo> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        return QueryUtils.fetchData(mUrl);
    }
}
