package com.example.davinder_pc.news;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Davinder-PC on 5/28/2017.
 */

public class NewsInfoAdapter extends ArrayAdapter<NewsInfo> {
    public NewsInfoAdapter(Context context, ArrayList<NewsInfo> newsInfo) {
        super(context, 0, newsInfo);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.item_list, parent, false);
        }
        NewsInfo thisNews = getItem(position);
        TextView title = (TextView) listView.findViewById(R.id.Title);
        title.setText(thisNews.getNewsTitle());
        TextView section = (TextView) listView.findViewById(R.id.Section);
        section.setText(thisNews.getNewsSection());
        return listView;
    }
}
