package com.example.davinder_pc.news;

/**
 * Created by Davinder-PC on 5/28/2017.
 */

public class NewsInfo {
    final String mNewsTitle;
    final String mNewsSection;
    final String mNewsUrl;

    public NewsInfo(String newsTitle, String newsSection, String newsUrl) {
        mNewsTitle = newsTitle;
        mNewsSection = newsSection;
        mNewsUrl = newsUrl;
    }

    public String getNewsTitle() {

        return mNewsTitle;
    }

    public String getNewsSection() {
        return mNewsSection;
    }

    public String getNewsUrl() {

        return mNewsUrl;
    }
}
