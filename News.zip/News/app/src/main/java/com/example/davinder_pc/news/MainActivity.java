package com.example.davinder_pc.news;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<NewsInfo>> {
    private static final String NEWS_API_URL = "https://content.guardianapis.com/search?api-key=b6982911-dfb7-40a8-9443-f9485cc6c1ce";
    private static int LOADER_ID = 1;
    View Indicator;
    private NewsInfoAdapter mAdapter;
    private TextView EmptyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView newsList = (ListView) findViewById(R.id.list);

        mAdapter = new NewsInfoAdapter(MainActivity.this, new ArrayList<NewsInfo>());
        newsList.setAdapter(mAdapter);

        EmptyText = (TextView) findViewById(R.id.empty);
        newsList.setEmptyView(EmptyText);

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            android.app.LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(LOADER_ID, null, this);
        } else {
            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);
            EmptyText.setText(R.string.no_internet_connection);
        }
        newsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long lp) {
                NewsInfo thisNews = mAdapter.getItem(position);
                Uri allNews = Uri.parse(thisNews.getNewsUrl());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, allNews);
                startActivity(websiteIntent);
            }
        });
    }

    @Override
    public Loader<List<NewsInfo>> onCreateLoader(int i, Bundle bundle) {
        return new NewsInfoLoader(this, NEWS_API_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<NewsInfo>> loader, List<NewsInfo> data) {
        View Indicator = findViewById(R.id.loading_indicator);
        Indicator.setVisibility(View.GONE);
        EmptyText.setText(R.string.nothing);
        mAdapter.clear();
        if (data != null && !data.isEmpty()) {
            mAdapter.addAll(data);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<NewsInfo>> loader) {
        mAdapter.clear();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        EmptyText.setText(R.string.refresh);
        getLoaderManager().destroyLoader(LOADER_ID);
        getLoaderManager().initLoader(LOADER_ID, null, this);
        return true;
    }
}
