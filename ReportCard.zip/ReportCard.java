package com.example.davinder_pc.reportcard;

/**
 * Created by Davinder-PC on 5/13/2017.
 */

public class ReportCard {

    private String mHistory_Grades;
    private int mHistory_Score;

    private String mCriminology_Grades;
    private int mCriminology_Score;

    private String mPsychology_Grades;
    private int mPsychology_Score;

    public ReportCard(int history_score, int criminology_score, int psychology_score) {
        mHistory_Score = history_score;
        mCriminology_Score = criminology_score;
        mPsychology_Score = psychology_score;
    }

    //calculation of the grades
    public String calculateGrades(int score) {
        if (score >= 90)
            return "A";
        else if (score >= 85)
            return "A-";
        else if (score >= 80)
            return "B";
        else if (score >= 75)
            return "B-";
        else if (score >= 65)
            return "C";
        else if (score >= 55)
            return "C-";
        else if (score >= 50)
            return "D";
        else if (score >= 40)
            return "D-";
        else
            return "E";
    }
    
    public void setHistory_Grades() {
        mHistory_Grades = calculateGrades(mHistory_Score);
    }

    public void setCriminology_Grades() {

        mCriminology_Grades = calculateGrades(mCriminology_Score);
    }

    public void setPsychology_Grades() {

        mPsychology_Grades = calculateGrades(mPsychology_Score);
    }

    //Return Grades of Subjects
    public String getHistory_Grades() {

        return mHistory_Grades;
    }

    public String getmCriminology_Grades() {

        return mCriminology_Grades;
    }

    public String getmPsychology_Grades() {

        return mPsychology_Grades;
    }


    //overriding the toString() method
    @Override
    public String toString() {
        return "History Grades : " + getHistory_Grades() + "\nCriminology Grade : " + getmCriminology_Grades() +
                "\nPsychology Grades : " + getmPsychology_Grades();
    }
}