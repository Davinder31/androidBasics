package com.example.davinder_pc.habittracker;

import android.provider.BaseColumns;

/**
 * Created by Davinder-PC on 5/16/2017.
 */

public final class HabitContract {
    public static abstract class Habits implements BaseColumns{
        public static final String TABLE_NAME = "Habit_tracker";
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_HABIT_RUNNING = "runDistance";
        public static final String COLUMN_COMMENT = "comment";
    }
}
