package com.example.davinder_pc.habittracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.davinder_pc.habittracker.HabitContract.Habits;


/**
 * Created by Davinder-PC on 5/16/2017.
 */

public class HabitDbHelper extends SQLiteOpenHelper{
    private static final String DB_NAME = "tracker.db";

    private static final int DB_VERSION = 1;

    public HabitDbHelper(Context context) {super(context, DB_NAME, null, DB_VERSION); }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String HABIT_TRACK = "CREATE TABLE " + Habits.TABLE_NAME + "("
                + Habits._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Habits.COLUMN_NAME + " TEXT NOT NULL, "
                + Habits.COLUMN_HABIT_RUNNING + " INTEGER NOT NULL, "
                + Habits.COLUMN_COMMENT + " TEXT); ";

        database.execSQL(HABIT_TRACK);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE IF EXISTS " + Habits.TABLE_NAME);
        onCreate(database);
    }

    public void addHabit(String name, int habit_runningDistance, String comment){
        SQLiteDatabase database = getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(Habits.COLUMN_NAME, name);
        value.put(Habits.COLUMN_HABIT_RUNNING, habit_runningDistance);
        value.put(Habits.COLUMN_COMMENT, comment);
        database.insert(Habits.TABLE_NAME, null, value);
        database.close();
    }

    public Cursor getData(String name){
        SQLiteDatabase database = getReadableDatabase();
        Cursor option = database.rawQuery(
                "SELECT * FROM " + Habits.TABLE_NAME +
                        " WHERE name= " + name, null);
        return option;
    }
}

