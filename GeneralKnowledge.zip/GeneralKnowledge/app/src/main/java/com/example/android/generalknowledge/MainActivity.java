package com.example.android.generalknowledge;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.android.generalknowledge.R.id.australia;
import static com.example.android.generalknowledge.R.id.botswana;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
     int score;
    public void submitScore(View view) {
        EditText nameField1 = (EditText) findViewById(R.id.delhi);
        String capital = nameField1.getText().toString();
        EditText nameField2 = (EditText) findViewById(R.id.trump);
        String president = nameField2.getText().toString();
        EditText nameField3 = (EditText) findViewById(R.id.panipat);
        String battle = nameField3.getText().toString();
        int textField = calculateTextField(capital, president, battle);
        CheckBox vatican = (CheckBox) findViewById(R.id.vatican);
        CheckBox palestine = (CheckBox) findViewById(R.id.palestine);
        CheckBox australia = (CheckBox) findViewById(R.id.australia);
        CheckBox botswana = (CheckBox) findViewById(R.id.botswana);
        boolean checkVatican = vatican.isChecked();
        boolean checkPalestine = palestine.isChecked();
        boolean checkAustralia = australia.isChecked();
        boolean checkBotswana = botswana.isChecked();
        int checkbox = calculateCheckbox(checkVatican, checkPalestine, checkAustralia, checkBotswana);
        int total = calculateTotal(textField, checkbox);
        displayScore(total);
        Button submit = (Button) findViewById(R.id.submitButton);
        Context context = getApplicationContext();
        CharSequence text = "Score: " + score;
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 6);
        toast.show();
        submit.setEnabled(false);
    }
 // calculate score of checkbox
    private int calculateCheckbox(boolean checkVatican, boolean checkPalestine, boolean checkAustralia, boolean checkBotswana) {
        int i = 0;
        if (checkVatican && checkPalestine && !checkAustralia && !checkBotswana) {
            i += 1;
        }
        return i;
    }
    // calculate score of editText
    private int calculateTextField(String capital, String president, String battle){
        int i = 0;
        if (capital.equalsIgnoreCase("New Delhi") )
            i += 1;
        if (president.equalsIgnoreCase("Donald Trump") )
            i += 1;
        if (battle.equalsIgnoreCase("1526") )
            i += 1;
        return i;
    }
    // calculate score of radio button
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        RadioButton africa = (RadioButton)findViewById(R.id.africa);
        if(africa.isChecked()){
            score += 1;
        }
    }
 // calculate the total score
    private int calculateTotal(int a, int b){
        score += a + b;
        return score;
    }
    // Display the result
    private void displayScore(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.Score);
        quantityTextView.setText(getString(R.string.score) + number);
    }

}

