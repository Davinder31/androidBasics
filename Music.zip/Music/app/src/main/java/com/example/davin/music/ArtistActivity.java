package com.example.davin.music;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ArtistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);

        TextView all_songs=(TextView)findViewById(R.id.allsongs);
        TextView nowPlaying=(TextView)findViewById(R.id.nowPlaying);
        TextView genres=(TextView)findViewById(R.id.genre);
        TextView albums=(TextView)findViewById(R.id.album);

        all_songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ArtistActivity.this,AllSongs.class);
                startActivity(i);
            }
        });
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ArtistActivity.this,MainActivity.class);
                startActivity(i);
            }
        });
        genres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ArtistActivity.this,GenreActivity.class);
                startActivity(i);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ArtistActivity.this,AlbumActivity.class);
                startActivity(i);
            }
        });

    }
}
