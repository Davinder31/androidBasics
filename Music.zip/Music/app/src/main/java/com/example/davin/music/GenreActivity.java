package com.example.davin.music;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.TextView;

public class GenreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genre);

        TextView all_songs=(TextView)findViewById(R.id.allsongs);
        TextView artists=(TextView)findViewById(R.id.artist);
        TextView nowPlaying=(TextView)findViewById(R.id.nowPlaying);
        TextView albums=(TextView)findViewById(R.id.album);

        all_songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GenreActivity.this,AllSongs.class);
                startActivity(i);
            }
        });
        artists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GenreActivity.this,ArtistActivity.class);
                startActivity(i);
            }
        });
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GenreActivity.this,MainActivity.class);
                startActivity(i);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GenreActivity.this,AlbumActivity.class);
                startActivity(i);
            }
        });

    }
}
