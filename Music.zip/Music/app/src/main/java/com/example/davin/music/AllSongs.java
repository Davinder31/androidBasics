package com.example.davin.music;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AllSongs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_songs);

        TextView nowplaying=(TextView)findViewById(R.id.nowPlaying);
        TextView artists=(TextView)findViewById(R.id.artist);
        TextView genres=(TextView)findViewById(R.id.genre);
        TextView albums=(TextView)findViewById(R.id.album);

        nowplaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AllSongs.this,MainActivity.class);
                startActivity(i);
            }
        });
        artists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AllSongs.this,ArtistActivity.class);
                startActivity(i);
            }
        });
        genres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AllSongs.this,GenreActivity.class);
                startActivity(i);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AllSongs.this,AlbumActivity.class);
                startActivity(i);
            }
        });

    }
}
