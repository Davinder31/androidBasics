package com.example.davinder_pc.tourguide;

/**
 * Created by Davinder-PC on 5/12/2017.
 */

public class guide {
    private static final int NO_IMAGE_PROVIDED = -1;
    private String mName;
    private String mInfo;
    private int mImageResourceId = NO_IMAGE_PROVIDED;

    public guide(String name, String info) {
        mName = name;
        mInfo = info;
    }

    public guide(String name, String info, int imageResourceId) {
        mName = name;
        mInfo = info;
        mImageResourceId = imageResourceId;
    }

    public String getName() {
        return mName;
    }

    public String getInfo() {
        return mInfo;
    }

    public int getImageResourceId() {
        return mImageResourceId;
    }

    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
}
