package com.example.davinder_pc.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Hotels extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_list);

        ArrayList<guide> words = new ArrayList<guide>();
        words.add(new guide(getString(R.string.hotel_1), getString(R.string.hotel_1_info), R.drawable.lemon_tree_hotel_indore));
        words.add(new guide(getString(R.string.hotel_2), getString(R.string.hotel_2_info), R.drawable.mittal_avenue_ujjain));
        words.add(new guide(getString(R.string.hotel_3), getString(R.string.hotel_3_info), R.drawable.radisson_blu_hotel_indore));
        words.add(new guide(getString(R.string.hotel_4), getString(R.string.hotel_4_info), R.drawable.radisson_jass_hotel_khajuraho));
        words.add(new guide(getString(R.string.hotel_5), getString(R.string.hotel_5_info), R.drawable.usha_kiran_palace));


        guideAdapter adapter = new guideAdapter(this, words, R.color.hotels);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);
    }
}
