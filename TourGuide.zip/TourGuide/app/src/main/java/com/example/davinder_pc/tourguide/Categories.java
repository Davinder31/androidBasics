package com.example.davinder_pc.tourguide;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Categories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        TextView places = (TextView) findViewById(R.id.places);


        places.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {

                Intent numbersIntent = new Intent(Categories.this, Places.class);


                startActivity(numbersIntent);
            }
        });


        TextView hotels = (TextView) findViewById(R.id.hotels);


        hotels.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the family category is clicked on.
            @Override
            public void onClick(View view) {

                Intent familyIntent = new Intent(Categories.this, Hotels.class);


                startActivity(familyIntent);
            }
        });


        TextView restaurants = (TextView) findViewById(R.id.restaurants);


        restaurants.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the colors category is clicked on.
            @Override
            public void onClick(View view) {

                Intent colorsIntent = new Intent(Categories.this, Restaurants.class);


                startActivity(colorsIntent);
            }
        });


        TextView events = (TextView) findViewById(R.id.events);


        events.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the phrases category is clicked on.
            @Override
            public void onClick(View view) {

                Intent phrasesIntent = new Intent(Categories.this, Events.class);


                startActivity(phrasesIntent);
            }
        });

    }
}
