package com.example.davinder_pc.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Places extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_list);

        ArrayList<guide> words = new ArrayList<guide>();
        words.add(new guide(getString(R.string.khaju), (getString(R.string.khaju_info)), R.drawable.khajuraho));
        words.add(new guide(getString(R.string.amar), (getString(R.string.amar_info)), R.drawable.amarkantak));
        words.add(new guide(getString(R.string.gwal), (getString(R.string.gwal_info)), R.drawable.gwalior));
        words.add(new guide(getString(R.string.sanchi), (getString(R.string.sanchi_info)), R.drawable.sanchi));
        words.add(new guide(getString(R.string.panch), (getString(R.string.panch_info)), R.drawable.panchmarhi));


        guideAdapter adapter = new guideAdapter(this, words, R.color.places);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);
    }
}
