package com.example.davinder_pc.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Events extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_list);

        ArrayList<guide> words = new ArrayList<guide>();
        words.add(new guide(getString(R.string.eve_1), (getString(R.string.eve_1_info)), R.drawable.lokrang));
        words.add(new guide(getString(R.string.eve_2), (getString(R.string.eve_2_info)), R.drawable.khajuraho_fest));
        words.add(new guide(getString(R.string.eve_3), (getString(R.string.eve_3_info)), R.drawable.kumbh_mela));
        words.add(new guide(getString(R.string.eve_4), (getString(R.string.eve_4_info)), R.drawable.malvautsav));
        words.add(new guide(getString(R.string.eve_5), (getString(R.string.eve_5_info)), R.drawable.holi));


        guideAdapter adapter = new guideAdapter(this, words, R.color.fun_events);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);
    }
}
