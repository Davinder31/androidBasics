package com.example.davinder_pc.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Restaurants extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_list);

        ArrayList<guide> words = new ArrayList<guide>();
        words.add(new guide(getString(R.string.res_1), getString(R.string.res_1_info), R.drawable.chotiwala));
        words.add(new guide(getString(R.string.res_2), getString(R.string.res_2_info), R.drawable.kebabsville));
        words.add(new guide(getString(R.string.res_3), getString(R.string.res_3_info), R.drawable.kwality));
        words.add(new guide(getString(R.string.res_4), getString(R.string.res_4_info), R.drawable.rajacafe));
        words.add(new guide(getString(R.string.res_5), getString(R.string.res_5_info), R.drawable.vijay_chaat_house));


        guideAdapter adapter = new guideAdapter(this, words, R.color.restaurants);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);
    }
}
