﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/29/2018
 * Time: 3:44 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace MVVMEmployee.Views
{
	/// <summary>
	/// Interaction logic for EmployeeView.xaml
	/// </summary>
	public partial class EmployeeView : UserControl
	{
		public EmployeeView()
		{
			InitializeComponent();
		}
		
		public static readonly DependencyProperty Emp_IDProperty =
			DependencyProperty.Register("Emp_ID", typeof(string), typeof(EmployeeView),
			                            new FrameworkPropertyMetadata());
		
		public string Emp_ID {
			get { return (string)GetValue(Emp_IDProperty); }
			set { SetValue(Emp_IDProperty, value); }
		}
		
		public static readonly DependencyProperty Emp_NameProperty =
			DependencyProperty.Register("Emp_Name", typeof(string), typeof(EmployeeView),
			                            new FrameworkPropertyMetadata());
		
		public string Emp_Name {
			get { return (string)GetValue(Emp_NameProperty); }
			set { SetValue(Emp_NameProperty, value); }
		}
		
		public static readonly DependencyProperty Emp_CityProperty =
			DependencyProperty.Register("Emp_City", typeof(string), typeof(EmployeeView),
			                            new FrameworkPropertyMetadata());
		
		public string Emp_City {
			get { return (string)GetValue(Emp_CityProperty); }
			set { SetValue(Emp_CityProperty, value); }
		}
		
		public static readonly DependencyProperty Emp_DesignationProperty =
			DependencyProperty.Register("Emp_Designation", typeof(string), typeof(EmployeeView),
			                            new FrameworkPropertyMetadata());
		
		public string Emp_Designation {
			get { return (string)GetValue(Emp_DesignationProperty); }
			set { SetValue(Emp_DesignationProperty, value); }
		}
	}
}