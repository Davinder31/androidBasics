﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/29/2018
 * Time: 3:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using MVVMEmployee.Model;
using MVVMEmployee.ViewModel;

namespace MVVMEmployee
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		EmployeeViewModel vm;
		public Window1()
		{
			InitializeComponent();
			vm = new EmployeeViewModel();
			//  list1.ItemsSource = vm.Employees;
			this.DataContext = vm;
		}
		void List1_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			var listbox = sender as ListBox;
			if (listbox.SelectedItem != null) {
				vm.SelectedEmployee = listbox.SelectedItem as Employee;
				contentControl.Content = vm.SelectedEmployee;
			}	
		}
		
		
	}
}