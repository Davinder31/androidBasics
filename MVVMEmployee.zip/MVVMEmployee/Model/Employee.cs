﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/29/2018
 * Time: 3:43 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;

namespace MVVMEmployee.Model
{
	/// <summary>
	/// Description of Employee.
	/// </summary>
	public class Employee : INotifyPropertyChanged
	{
		private string _Emp_ID;
		private string _Emp_Name;
		private string _Emp_City;
		private string _Emp_Designation;

		public Employee()
		{
		}
		
		public string Emp_ID {
			get{ return _Emp_ID; }
			set {
				_Emp_ID = value;
				PropertyChange("Emp_ID");
			}
		}
		
		public string Emp_Name {
			get{ return _Emp_Name; }
			set {
				_Emp_Name = value;
				PropertyChange("Emp_Name");
			}
		}
		
		public string Emp_City {
			get{ return _Emp_City; }
			set {
				_Emp_City = value;
				PropertyChange("Emp_City");
			}
		}
		
		public string Emp_Designation {
			get{ return _Emp_Designation; }
			set {
				_Emp_Designation = value;
				PropertyChange("Emp_Designation");
			}
		}
		
		public event PropertyChangedEventHandler PropertyChanged;
		
		void PropertyChange(string property)
		{
			if (PropertyChanged != null) {
				
				PropertyChanged(this, new PropertyChangedEventArgs(property));
				
			}
		}
	}
}
