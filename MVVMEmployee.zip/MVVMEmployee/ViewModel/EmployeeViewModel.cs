﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 01/29/2018
 * Time: 16:31
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.ObjectModel;
using System.Windows;
using MVVMEmployee.Model;

namespace MVVMEmployee.ViewModel
{
	/// <summary>
	/// Description of EmployeeViewModel.
	/// </summary>
	public class EmployeeViewModel
	{
		
		
		public RelayCommand DeleteCommand { get; set; }
		public RelayCommand AddCommand { get; set; }
		
		private Employee _newEmployee = new Employee();
		
		ObservableCollection<Employee> employees;
		public ObservableCollection<Employee> Employees { get { return employees; } }
		public EmployeeViewModel()
		{
			DeleteCommand = new RelayCommand(OnDelete, CanDelete);
			AddCommand = new RelayCommand(OnAdd);
			employees = new
				ObservableCollection<Employee>();
			employees.Add(new Employee {
			              	Emp_ID = "1",
			              	Emp_Name = "Allain",
			              	Emp_City = "Mohali",
			              	Emp_Designation = "Developer"
			              });
			employees.Add(new Employee {
			              	Emp_ID = "2",
			              	Emp_Name = "samrat",
			              	Emp_City = "Mohali",
			              	Emp_Designation = "Developer"
			              });
		}
		
		
		
		private Employee _selectedEmployee;
		
		public Employee SelectedEmployee {
			get {
				return this._selectedEmployee;
			}

			set {
				this._selectedEmployee = value;
				
			}
			
		}
		
		public Employee NewEmployee { get { return this._newEmployee;}
				set{this._newEmployee = value; }
			 }
		
	
		private void OnAdd(object ob)
		{
			employees.Add(_newEmployee);
			_newEmployee = new Employee();
			
		}
		
		private void OnDelete(object ob)
		{
			Employees.Remove(SelectedEmployee);
		}
		
		private bool CanDelete(object ob)
		{
			return SelectedEmployee != null;
		}
		
		
		
	}
}
