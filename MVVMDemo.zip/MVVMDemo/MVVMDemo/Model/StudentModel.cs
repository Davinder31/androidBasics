﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/24/2018
 * Time: 3:42 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.ComponentModel;

namespace MVVMDemo.Model
{
	/// <summary>
	/// Description of StudentModel.
	/// </summary>

	
	public class Student : INotifyPropertyChanged
	{
		string firstName;
		string lastName;
		
		public string FirstName {
			get { return firstName; }
			set {
				if (firstName != value) {
					
					firstName = value;
					RaisePropertyChanged("FirstName");
					RaisePropertyChanged("FullName");
				}
			}
		}
		
		public string LastName {
			get { return lastName; }
			set {
				if (lastName != value) {
					lastName = value;
					RaisePropertyChanged("LastName");
					RaisePropertyChanged("FullName");
				}
			}
		}
		public string FullName {
			get {
				return firstName + " " + lastName;
			}
		}
		public event PropertyChangedEventHandler PropertyChanged;
		private void RaisePropertyChanged(string property)
		{
			if (PropertyChanged != null) {
				PropertyChanged(this, new PropertyChangedEventArgs(property));
			}
		}
	}
}

