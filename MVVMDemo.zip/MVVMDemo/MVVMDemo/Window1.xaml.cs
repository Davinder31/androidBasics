﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/24/2018
 * Time: 3:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows;
using MVVMDemo.ViewModel;
namespace MVVMDemo
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
		
		private void StudentViewControl_Loaded(object sender, RoutedEventArgs e){
			StudentViewModel studentViewModelObject = new StudentViewModel();
			
			studentViewModelObject.LoadStudents();
			StudentViewControl.DataContext = studentViewModelObject;
		}
	}
}