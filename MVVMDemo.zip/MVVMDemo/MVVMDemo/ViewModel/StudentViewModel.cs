﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/24/2018
 * Time: 3:44 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using MVVMDemo.Model;
using System.Collections.ObjectModel;
namespace MVVMDemo.ViewModel
{
	public class StudentViewModel
	{
		public StudentViewModel(){
			LoadStudents();
		}
		
		public void LoadStudents()
		{
			ObservableCollection<Student> students = new
				ObservableCollection<Student>();
			students.Add(new Student { FirstName = "Raman", LastName = "Allain" });
			students.Add(new Student { FirstName = "Allen", LastName = "Brown" });
			students.Add(new Student { FirstName = "Linda", LastName = "Hamerski" });
			
		}
	}
}
