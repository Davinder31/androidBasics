﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 1/24/2018
 * Time: 4:13 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace MVVMDemo.Views
{
	/// <summary>
	/// Interaction logic for StudentView.xaml
	/// </summary>
	public partial class StudentView : UserControl
	{
		public StudentView()
		{
			InitializeComponent();
			
		}
	}
}