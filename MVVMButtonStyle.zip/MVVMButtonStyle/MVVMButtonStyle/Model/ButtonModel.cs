﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 2/7/2018
 * Time: 11:43 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;

namespace MVVMButtonStyle.Model
{
	/// <summary>
	/// Description of ButtonModel.
	/// </summary>
	public class ButtonModel : INotifyPropertyChanged
	{
		public ButtonModel()
		{
		}
		
		private string _background = "Red";
		private string _borderColor = "Black";
		private int _borderThickness = 2;
		private int _height = 50;
		private int _width = 100;
		private int _borderRadius = 2;
		
		
		public string Background {
			get { return _background; }
			set {
				_background = value;
				PropertyChange("Background");
			}
		}
		
		public int Height {
			get { return _height; }
			set {
				_height = value;
				PropertyChange("Height");
			}
		}
		
		public int BorderRadius {
			get { return _borderRadius; }
			set {
				_borderRadius = value;
				PropertyChange("BorderRadius");
			}
		}
		
		public int Width {
			get { return _width; }
			set {
				_width = value;
				PropertyChange("Width");
			}
		}
		
		public int BorderThickness {
			get { return _borderThickness; }
			set {
				_borderThickness = value;
				PropertyChange("BorderThickness");
			}
		}
		
		public string BorderColor {
			get { return _borderColor; }
			set {
				_borderColor = value;
				PropertyChange("BorderColor");
			}
		}
		
		public event PropertyChangedEventHandler PropertyChanged;
		
		void PropertyChange(string property)
		{
			if (PropertyChanged != null) {
				
				PropertyChanged(this, new PropertyChangedEventArgs(property));
				
			}
		}
	}
}
