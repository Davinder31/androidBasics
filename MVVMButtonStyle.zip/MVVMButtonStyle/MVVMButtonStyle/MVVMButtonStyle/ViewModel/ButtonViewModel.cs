﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 2/7/2018
 * Time: 11:44 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using MVVMButtonStyle.Model;

namespace MVVMButtonStyle.ViewModel
{
	/// <summary>
	/// Description of ButtonViewModel.
	/// </summary>
	 class ButtonViewModel : INotifyPropertyChanged
	{
		ButtonModel btn = new ButtonModel();
		
		
		public RelayCommand AddCommand { get; set; }
		public RelayCommand NewCommand { get; set; }
		public RelayCommand DeleteCommand { get; set; }
		
		public ObservableCollection<ButtonModel> Buttons { get { return this.buttons; } set { this.buttons = value; } }
		ObservableCollection<ButtonModel> buttons;
		public ButtonViewModel()
		{
			thisButton = null;
			AddCommand = new RelayCommand(OnAdd);
			NewCommand = new RelayCommand(OnNew);
			DeleteCommand = new RelayCommand(OnDelete,CanDelete);
			
			buttons = new ObservableCollection<ButtonModel>();
		}
		
		public ButtonModel thisButton {
			get { return btn; }
			set {
				btn = value;
				PropertyChange("thisButton");
			}
		}
		
		public ButtonModel SelectedButton {
			get {
				return this.btn;
			}

			set {
				this.btn = value;
				
			}
			
		}
		
		
		public void OnNew(object ob)
		{
		 btn = new ButtonModel();
			thisButton = btn;
		}
		
		
		private void OnAdd(object ob)
		{
			buttons.Add(thisButton);
			thisButton = null;
		}
		
		private void OnDelete(object ob)
		{
			Buttons.Remove(SelectedButton);
		}
		
		private bool CanDelete(object ob)
		{
			return SelectedButton != null;
		}
		
		public event PropertyChangedEventHandler PropertyChanged;
		
		void PropertyChange(string property)
		{
			if (PropertyChanged != null) {
				
				PropertyChanged(this, new PropertyChangedEventArgs(property));
				
			}
		}
		
	}
}
