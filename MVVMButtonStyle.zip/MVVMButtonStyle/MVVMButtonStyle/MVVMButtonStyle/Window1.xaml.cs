﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 2/7/2018
 * Time: 11:42 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Windows;
using System.Windows.Controls;
using MVVMButtonStyle.Model;
using MVVMButtonStyle.ViewModel;

namespace MVVMButtonStyle
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		
		ButtonViewModel buttonViewModel = new ButtonViewModel();
		public Window1()
		{
			InitializeComponent();
			this.DataContext = buttonViewModel;
			}
	
		
		void List1_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			var listbox = sender as ListBox;
			if (listbox.SelectedItem != null) {
				buttonViewModel.SelectedButton = listbox.SelectedItem as ButtonModel;
			}	
		}
		
	}
}