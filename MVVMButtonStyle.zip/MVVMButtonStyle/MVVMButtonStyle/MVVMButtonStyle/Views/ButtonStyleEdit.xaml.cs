﻿/*
 * Created by SharpDevelop.
 * User: davinder
 * Date: 2/7/2018
 * Time: 11:46 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace MVVMButtonStyle.Views
{
	/// <summary>
	/// Interaction logic for ButtonStyleEdit.xaml
	/// </summary>
	public partial class ButtonStyleEdit : UserControl
	{
		public ButtonStyleEdit()
		{
			InitializeComponent();
		}
	}
}